<?php defined( 'ABSPATH' ) or die(); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php _e('No access', 'ylt-dev'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans%3A400%2C300&ver=3.9.2" />
    <style type="text/css">
    html
    {
        background-color: #f6f6f6;
    }

    body
    {
        max-width: 600px;
        margin: 30px auto;
        text-align: center;
        background-color: #fff;
        padding: 30px;
        font-family: "Open Sans", HelveticaNeue, "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-size: 16px;
    }

    .logo
    {
        max-width: 100%;
    }

    h1
    {
        color: #DB3E87;
        font-size: 2rem;
        font-weight: bold;
    }
    </style>
</head>
<body>

    <a href="https://yellowlemontree.nl" target="_blank">
        <img class="logo" src="<?php echo PLUGIN_URL; ?>yellowlemontree.png" alt="Yellow Lemon Tree" />
    </a>

    <h1><?php _e('No access', 'ylt-dev'); ?></h1>
    <p><?php _e('You don\'t have access to this website', 'ylt-dev'); ?></p>

</body>
</html>
