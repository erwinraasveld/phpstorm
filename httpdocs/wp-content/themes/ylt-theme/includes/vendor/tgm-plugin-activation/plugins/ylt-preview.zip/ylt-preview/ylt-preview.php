<?php

/*
Plugin Name: YLT Preview
Description: Schermt de website af en maakt deze alleen zichtbaar met &lsquo;?preview&rsquo;.
Author: Yellow Lemon Tree
Version: 1.0
Author URI: http://yellowlemontree.nl/
Text Domain: ylt-dev
Domain Path: /lang/
*/





/*
 * Check ABSPATH for security
 */
defined( 'ABSPATH' ) or die();





/*
 * Configs
 */
define( 'PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'PLUGIN_URL', plugin_dir_url( __FILE__ ) );





/*
 * Add preview functionality
 */
function add_preview_header ()
{
    // No access file template
    $noAccessFile = 'no-access.php';


    // Only check access if the user isn't logged in
    if ( ! is_user_logged_in() )
    {
        session_start();

        // Check if ?preview exists and set the session
        if ( isset($_GET['preview']) )
        {
            $_SESSION['preview'] = true;


            // Redirect to URL without '?preview'
            $redirect_url = home_url();

            header('Location: '. $redirect_url);
            exit();
        }

        // If the user doesn't have access show the no access file
        if ( ! isset($_SESSION['preview']) )
        {
            $noAccessFile = PLUGIN_PATH . $noAccessFile;
            require($noAccessFile);
            http_response_code(403);
            exit;
        }
    }
}
add_action( 'init', 'add_preview_header' );





/*
 * Load textdomain for translations
 */
function ylt_load_textdomain ()
{
	load_plugin_textdomain( 'ylt-dev', false, dirname( plugin_basename(__FILE__) ) . '/lang/' );
}
add_action('plugins_loaded', 'ylt_load_textdomain');
