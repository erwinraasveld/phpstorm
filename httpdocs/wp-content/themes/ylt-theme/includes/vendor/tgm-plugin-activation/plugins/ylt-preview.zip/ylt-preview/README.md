# YLT Preview

## Plugin
Schermt de website af en maakt deze alleen zichtbaar met ‘?preview’.

## Installatie
Plaats ylt-preview in de plugins map en activeer via wp-admin

## Vertalingen
- Engels
- Nederlands